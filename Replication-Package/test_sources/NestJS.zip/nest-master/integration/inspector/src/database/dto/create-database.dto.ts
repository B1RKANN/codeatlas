export class CreateDatabaseDto {}
