export class Dog {}
