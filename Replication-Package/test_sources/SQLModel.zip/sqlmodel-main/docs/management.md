# Repository Management

Here's a short description of how the SQLModel repository is managed and maintained.

## Owner

I, [@tiangolo](https://github.com/tiangolo), am the creator and owner of the SQLModel repository. 🤓

I normally give the final review to each PR before merging them. I make the final decisions on the project, I'm the [<abbr title="Benevolent Dictator For Life">BDFL</abbr>](https://en.wikipedia.org/wiki/Benevolent_dictator_for_life). 😅

## Team

There's a team of people that help manage and maintain the project. 😎

Learn more about it in [tiangolo.com - GitHub FastAPI](https://tiangolo.com/github-fastapi/).

## External Help

External help is very much appreciated. There are many ways to [help](./help.md). ☕️
