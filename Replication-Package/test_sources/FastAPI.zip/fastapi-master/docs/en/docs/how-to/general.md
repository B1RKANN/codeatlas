# General - How To - Recipes { #general-how-to-recipes }

Here are several pointers to other places in the docs, for general or frequent questions.

## Filter Data - Security { #filter-data-security }

To ensure that you don't return more data than you should, read the docs for [Tutorial - Response Model - Return Type](../tutorial/response-model.md).

## Optimize Response Performance - Response Model - Return Type { #optimize-response-performance-response-model-return-type }

To optimize performance when returning JSON data, use a return type or response model, that way Pydantic will handle the serialization to JSON on the Rust side, without going through Python. Read more in the docs for [Tutorial - Response Model - Return Type](../tutorial/response-model.md).

## Documentation Tags - OpenAPI { #documentation-tags-openapi }

To add tags to your *path operations*, and group them in the docs UI, read the docs for [Tutorial - Path Operation Configurations - Tags](../tutorial/path-operation-configuration.md#tags).

## Documentation Summary and Description - OpenAPI { #documentation-summary-and-description-openapi }

To add a summary and description to your *path operations*, and show them in the docs UI, read the docs for [Tutorial - Path Operation Configurations - Summary and Description](../tutorial/path-operation-configuration.md#summary-and-description).

## Documentation Response description - OpenAPI { #documentation-response-description-openapi }

To define the description of the response, shown in the docs UI, read the docs for [Tutorial - Path Operation Configurations - Response description](../tutorial/path-operation-configuration.md#response-description).

## Documentation Deprecate a *Path Operation* - OpenAPI { #documentation-deprecate-a-path-operation-openapi }

To deprecate a *path operation*, and show it in the docs UI, read the docs for [Tutorial - Path Operation Configurations - Deprecation](../tutorial/path-operation-configuration.md#deprecate-a-path-operation).

## Convert any Data to JSON-compatible { #convert-any-data-to-json-compatible }

To convert any data to JSON-compatible, read the docs for [Tutorial - JSON Compatible Encoder](../tutorial/encoder.md).

## OpenAPI Metadata - Docs { #openapi-metadata-docs }

To add metadata to your OpenAPI schema, including a license, version, contact, etc, read the docs for [Tutorial - Metadata and Docs URLs](../tutorial/metadata.md).

## OpenAPI Custom URL { #openapi-custom-url }

To customize the OpenAPI URL (or remove it), read the docs for [Tutorial - Metadata and Docs URLs](../tutorial/metadata.md#openapi-url).

## OpenAPI Docs URLs { #openapi-docs-urls }

To update the URLs used for the automatically generated docs user interfaces, read the docs for [Tutorial - Metadata and Docs URLs](../tutorial/metadata.md#docs-urls).
