# Configura Swagger UI { #configure-swagger-ui }

Puedes configurar algunos [parámetros adicionales de Swagger UI](https://swagger.io/docs/open-source-tools/swagger-ui/usage/configuration/).

Para configurarlos, pasa el argumento `swagger_ui_parameters` al crear el objeto de la app `FastAPI()` o a la función `get_swagger_ui_html()`.

`swagger_ui_parameters` recibe un diccionario con las configuraciones pasadas directamente a Swagger UI.

FastAPI convierte las configuraciones a **JSON** para hacerlas compatibles con JavaScript, ya que eso es lo que Swagger UI necesita.

## Desactiva el resaltado de sintaxis { #disable-syntax-highlighting }

Por ejemplo, podrías desactivar el resaltado de sintaxis en Swagger UI.

Sin cambiar la configuración, el resaltado de sintaxis está activado por defecto:

<img src="/img/tutorial/extending-openapi/image02.png">

Pero puedes desactivarlo estableciendo `syntaxHighlight` en `False`:

{* ../../docs_src/configure_swagger_ui/tutorial001_py310.py hl[3] *}

...y entonces Swagger UI ya no mostrará el resaltado de sintaxis:

<img src="/img/tutorial/extending-openapi/image03.png">

## Cambia el tema { #change-the-theme }

De la misma manera, podrías configurar el tema del resaltado de sintaxis con la clave `"syntaxHighlight.theme"` (ten en cuenta que tiene un punto en el medio):

{* ../../docs_src/configure_swagger_ui/tutorial002_py310.py hl[3] *}

Esa configuración cambiaría el tema de color del resaltado de sintaxis:

<img src="/img/tutorial/extending-openapi/image04.png">

## Cambia los parámetros por defecto de Swagger UI { #change-default-swagger-ui-parameters }

FastAPI incluye algunos parámetros de configuración por defecto apropiados para la mayoría de los casos de uso.

Incluye estas configuraciones por defecto:

{* ../../fastapi/openapi/docs.py ln[9:24] hl[18:24] *}

Puedes sobrescribir cualquiera de ellos estableciendo un valor diferente en el argumento `swagger_ui_parameters`.

Por ejemplo, para desactivar `deepLinking` podrías pasar estas configuraciones a `swagger_ui_parameters`:

{* ../../docs_src/configure_swagger_ui/tutorial003_py310.py hl[3] *}

## Otros parámetros de Swagger UI { #other-swagger-ui-parameters }

Para ver todas las demás configuraciones posibles que puedes usar, lee la [documentación oficial de los parámetros de Swagger UI](https://swagger.io/docs/open-source-tools/swagger-ui/usage/configuration/).

## Configuraciones solo de JavaScript { #javascript-only-settings }

Swagger UI también permite otras configuraciones que son objetos **solo de JavaScript** (por ejemplo, funciones de JavaScript).

FastAPI también incluye estas configuraciones `presets` solo de JavaScript:

```JavaScript
presets: [
    SwaggerUIBundle.presets.apis,
    SwaggerUIBundle.SwaggerUIStandalonePreset
]
```

Estos son objetos de **JavaScript**, no strings, por lo que no puedes pasarlos directamente desde código de Python.

Si necesitas usar configuraciones solo de JavaScript como esas, puedes usar uno de los métodos anteriores. Sobrescribe toda la *path operation* de Swagger UI y escribe manualmente cualquier JavaScript que necesites.
